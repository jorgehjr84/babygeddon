// var dateString = req.slot('DATE');
// var month;
// var day;
// var year;

//     if(dateString.includes('january')){
//           month = 'january ';
//     }else if(dateString.includes('february')){
//           month = 'february ';
//     }else if(dateString.includes('march')){
//           month = 'march ';
//     }else if(dateString.includes('april')){
//           month = 'april ';
//     }else if(dateString.includes('may')){
//           month = 'may ';
//     }else if(dateString.includes('june')){
//           month = 'june ';
//     }else if(dateString.includes('july')){
//           month = 'july ';
//     }else if(dateString.includes('august')){
//           month = 'august ';
//     }else if(dateString.includes('september')){
//           month = 'september ';
//     }else if(dateString.includes('october')){
//           month = 'october ';
//     }else if(dateString.includes('november')){
//           month = 'november ';
//     }else{
//           month = 'december ';
//     }
    

//     if(dateString.includes('tenth')){
//           day = '10 ';
//     }else if(dateString.includes('eleventh')){
//           day = '11 ';
//     }else if(dateString.includes('twelfth')){
//           day = '12 ';
//     }else if(dateString.includes('thirteenth')){
//           day = '13 ';
//     }else if(dateString.includes('fourteenth')){
//           day = '14 ';
//     }else if(dateString.includes('fifteenth')){
//           day = '15 ';
//     }else if(dateString.includes('sixteenth')){
//           day = '16 ';
//     }else if(dateString.includes('seventeenth')){
//           day = '17 ';
//     }else if(dateString.includes('eighteenth')){
//           day = '18 ';
//     }else if(dateString.includes('nineteenth')){
//           day = '19 ';
//     }else if(dateString.includes('twentieth')){
//           day = '20 ';
//     }else if(dateString.includes('twenty first')){
//           day = '21 ';
//     }else if(dateString.includes('twenty second')){
//           day = '22 ';
//     }else if(dateString.includes('twenty third')){
//           day = '23 ';
//     }else if(dateString.includes('twenty fourth')){
//           day = '24 ';
//     }else if(dateString.includes('twenty fifth')){
//           day = '25 ';
//     }else if(dateString.includes('twenty sixth')){
//           day = '26 ';
//     }else if(dateString.includes('twenty seventh')){
//           day = '27 ';
//     }else if(dateString.includes('twenty eighth')){
//           day = '28 ';
//     }else if(dateString.includes('twenty ninth')){
//           day = '29 ';
//     }else if(dateString.includes('thirtieth')){
//           day = '30 ';
//     }else if(dateString.includes('thirty first')){
//           day = '31 ';
//     }else if(dateString.includes('first')){
//           day = '1 ';
//     }else if(dateString.includes('second')){
//           day = '2 ';
//     }else if(dateString.includes('third')){
//           day = '3 ';
//     }else if(dateString.includes('fourth')){
//           day = '4 ';
//     }else if(dateString.includes('fifth')){
//           day = '5 ';
//     }else if(dateString.includes('sixth')){
//           day = '6 ';
//     }else if(dateString.includes('seventh')){
//           day = '7 ';
//     }else if(dateString.includes('eigth')){
//           day = '8 ';
//     }else if(dateString.includes('ninth')){
//           day = '9 ';
//     }else {
//           day = '31 ';
//     }

// if(dateString.includes('twenty sixteen')){
//           year = '2016';
//     }else if(dateString.includes('twenty seventeen')){
//           year = '2017';
//     }else if(dateString.includes('twenty eighteen')){
//           year = '2018';
//     }else if(dateString.includes('twenty nineteen')){
//           year = '2019';
//     }else{
//           year = '2020';
//     }


//var newDate = month + day + year;